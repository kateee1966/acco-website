package com.accommodation.model;

public class CommonVars {
    public static final String SESSION_LOGIN_KEY = "SESSION_LOGIN_KEY";
}
