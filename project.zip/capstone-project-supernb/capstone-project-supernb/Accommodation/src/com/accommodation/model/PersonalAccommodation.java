package com.accommodation.model;

import java.util.ArrayList;
import java.util.Date;

public class PersonalAccommodation extends Accommodation {
    private String structureType;
    private String rentType;
    private Integer bedroom;
    private Integer bathroom;
    private Integer kitchen;
    private Integer park;
    private Integer gym;
    private Integer wifi;
    private Integer lift;
    private Integer television;

    public PersonalAccommodation(){
        super();
    }

    @Override
    public String toString() {
        return "PersonalAccommodation{" +
                "structureType='" + structureType + '\'' +
                ", rentType='" + rentType + '\'' +
                ", bedroom=" + bedroom +
                ", bathroom=" + bathroom +
                ", kitchen=" + kitchen +
                ", park=" + park +
                ", gym=" + gym +
                ", wifi=" + wifi +
                ", lift=" + lift +
                ", television=" + television +
                "} " + super.toString();
    }

    public String getStructureType() {
        return structureType;
    }

    public void setStructureType(String structureType) {
        this.structureType = structureType;
    }

    public String getRentType() {
        return rentType;
    }

    public void setRentType(String rentType) {
        this.rentType = rentType;
    }

    public Integer getBedroom() {
        return bedroom;
    }

    public void setBedroom(Integer bedroom) {
        this.bedroom = bedroom;
    }

    public Integer getBathroom() {
        return bathroom;
    }

    public void setBathroom(Integer bathroom) {
        this.bathroom = bathroom;
    }

    public Integer getKitchen() {
        return kitchen;
    }

    public void setKitchen(Integer kitchen) {
        this.kitchen = kitchen;
    }

    public Integer getPark() {
        return park;
    }

    public void setPark(Integer park) {
        this.park = park;
    }

    public Integer getGym() {
        return gym;
    }

    public void setGym(Integer gym) {
        this.gym = gym;
    }

    public Integer getWifi() {
        return wifi;
    }

    public void setWifi(Integer wifi) {
        this.wifi = wifi;
    }

    public Integer getLift() {
        return lift;
    }

    public void setLift(Integer lift) {
        this.lift = lift;
    }

    public Integer getTelevision() {
        return television;
    }

    public void setTelevision(Integer television) {
        this.television = television;
    }

    public PersonalAccommodation(Integer accommodationID, String title, String photoPath0, String photoPath1, String photoPath2, String photoPath3, String photoPath4, String photoPath5, String photoPath6, String photoPath7, String photoPath8, Double pricePerDay, String city, String address, String suburb, Integer postCode, Date startDate, Date endDate, String startDateString, String endDateString, Integer pet, String userName, Integer guestNum, String description, String accommodationType, Integer whetherComplete, String structureType, String rentType, Integer bedroom, Integer bathroom, Integer kitchen, Integer park, Integer gym, Integer wifi, Integer lift, Integer television) {
        super(accommodationID, title, photoPath0, photoPath1, photoPath2, photoPath3, photoPath4, photoPath5, photoPath6, photoPath7, photoPath8, pricePerDay, city, address, suburb, postCode, startDate, endDate, startDateString, endDateString, pet, userName, guestNum, description, accommodationType, whetherComplete);
        this.structureType = structureType;
        this.rentType = rentType;
        this.bedroom = bedroom;
        this.bathroom = bathroom;
        this.kitchen = kitchen;
        this.park = park;
        this.gym = gym;
        this.wifi = wifi;
        this.lift = lift;
        this.television = television;
    }
}
