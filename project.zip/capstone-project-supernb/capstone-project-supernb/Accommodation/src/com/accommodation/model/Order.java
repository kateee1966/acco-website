package com.accommodation.model;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Order {
    private Integer OrderID;
    private Integer accommodationID;
    private String sellerName;
    private String buyerName;
    private Date orderCreatedDate;
    private Date startDate;
    private Date endDate;
    private String orderCreatedDateString;
    private String startDateString;
    private String endDateString;
    private Integer guestNumber;
    private Double amount;
    private Integer whetherRate;

    public Order(){
        this.startDate = new Date();
        this.endDate = new Date();
        this.orderCreatedDate = new Date();
    }

    public Date getOrderCreatedDate() {
        return orderCreatedDate;
    }

    public void setOrderCreatedDate(Date orderCreatedDate) {
        this.orderCreatedDate = orderCreatedDate;
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MM/yyyy");
        this.orderCreatedDateString = simpleDateFormat.format(orderCreatedDate);
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MM/yyyy");
        this.startDateString = simpleDateFormat.format(startDate);
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MM/yyyy");
        this.endDateString = simpleDateFormat.format(endDate);
    }

    public String getOrderCreatedDateString() {
        return orderCreatedDateString;
    }

    public void setOrderCreatedDateString(String orderCreatedDateString) throws ParseException {
        this.orderCreatedDateString = orderCreatedDateString;
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MM/yyyy");
        this.orderCreatedDate = simpleDateFormat.parse(orderCreatedDateString);
    }

    public String getStartDateString() {
        return startDateString;
    }

    public void setStartDateString(String startDateString) throws ParseException {
        this.startDateString = startDateString;
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MM/yyyy");
        this.startDate = simpleDateFormat.parse(startDateString);
    }

    public String getEndDateString() {
        return endDateString;
    }

    public void setEndDateString(String endDateString) throws ParseException {
        this.endDateString = endDateString;
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MM/yyyy");
        this.endDate = simpleDateFormat.parse(endDateString);
    }

    @Override
    public String toString() {
        return "Order{" +
                "OrderID='" + OrderID + '\'' +
                ", accommodationID='" + accommodationID + '\'' +
                ", sellerName='" + sellerName + '\'' +
                ", buyerName='" + buyerName + '\'' +
                ", orderCreatedDate=" + orderCreatedDate +
                ", startDate=" + startDate +
                ", endDate=" + endDate +
                ", orderCreatedDateString='" + orderCreatedDateString + '\'' +
                ", startDateString='" + startDateString + '\'' +
                ", endDateString='" + endDateString + '\'' +
                ", guestNumber=" + guestNumber +
                ", amount=" + amount +
                ", whetherRate=" + whetherRate +
                '}';
    }


    public String getSellerName() {
        return sellerName;
    }

    public void setSellerName(String sellerName) {
        this.sellerName = sellerName;
    }

    public String getBuyerName() {
        return buyerName;
    }

    public void setBuyerName(String buyerName) {
        this.buyerName = buyerName;
    }

    public Integer getGuestNumber() {
        return guestNumber;
    }

    public void setGuestNumber(Integer guestNumber) {
        this.guestNumber = guestNumber;
    }

    public Double getAmount() {
        return amount;
    }

    public void setAmount(Double amount) {
        this.amount = amount;
    }

    public Integer getWhetherRate() {
        return whetherRate;
    }

    public void setWhetherRate(Integer whetherRate) {
        this.whetherRate = whetherRate;
    }

    public Integer getOrderID() {
        return OrderID;
    }

    public void setOrderID(Integer orderID) {
        OrderID = orderID;
    }

    public Integer getAccommodationID() {
        return accommodationID;
    }

    public void setAccommodationID(Integer accommodationID) {
        this.accommodationID = accommodationID;
    }

    public Order(Integer orderID, Integer accommodationID, String sellerName, String buyerName, Date orderCreatedDate, Date startDate, Date endDate, String orderCreatedDateString, String startDateString, String endDateString, Integer guestNumber, Double amount, Integer whetherRate) {
        OrderID = orderID;
        this.accommodationID = accommodationID;
        this.sellerName = sellerName;
        this.buyerName = buyerName;
        this.orderCreatedDate = orderCreatedDate;
        this.startDate = startDate;
        this.endDate = endDate;
        this.orderCreatedDateString = orderCreatedDateString;
        this.startDateString = startDateString;
        this.endDateString = endDateString;
        this.guestNumber = guestNumber;
        this.amount = amount;
        this.whetherRate = whetherRate;
    }
}
