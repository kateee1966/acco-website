package com.accommodation.model;

import java.util.ArrayList;
import java.util.Date;

public class CompanyAccommodation extends Accommodation {
    private String hotelType;
    private Integer star;
    private String url;

    public CompanyAccommodation(){
        super();
    }

    @Override
    public String toString() {
        return "CompanyAccommodation{" +
                "hotelType='" + hotelType + '\'' +
                ", star=" + star +
                ", url='" + url + '\'' +
                "} " + super.toString();
    }

    public String getHotelType() {
        return hotelType;
    }

    public void setHotelType(String hotelType) {
        this.hotelType = hotelType;
    }

    public Integer getStar() {
        return star;
    }

    public void setStar(Integer star) {
        this.star = star;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public CompanyAccommodation(Integer accommodationID, String title, String photoPath0, String photoPath1, String photoPath2, String photoPath3, String photoPath4, String photoPath5, String photoPath6, String photoPath7, String photoPath8, Double pricePerDay, String city, String address, String suburb, Integer postCode, Date startDate, Date endDate, String startDateString, String endDateString, Integer pet, String userName, Integer guestNum, String description, String accommodationType, Integer whetherComplete, String hotelType, Integer star, String url) {
        super(accommodationID, title, photoPath0, photoPath1, photoPath2, photoPath3, photoPath4, photoPath5, photoPath6, photoPath7, photoPath8, pricePerDay, city, address, suburb, postCode, startDate, endDate, startDateString, endDateString, pet, userName, guestNum, description, accommodationType, whetherComplete);
        this.hotelType = hotelType;
        this.star = star;
        this.url = url;
    }
}
