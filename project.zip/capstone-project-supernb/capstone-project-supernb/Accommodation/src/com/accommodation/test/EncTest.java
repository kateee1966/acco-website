package com.accommodation.test;

import com.accommodation.dao.OrderDao;
import com.accommodation.dao.UserDao;
import com.accommodation.model.IndividualUser;
import com.accommodation.utils.EncUtils;
import org.junit.Test;

public class EncTest {
    @Test
    public void testEnc() throws Exception {
        System.out.println(EncUtils.encryptString("33333333"));
        System.out.println(EncUtils.encryptString("11111111"));
        //x75RWNJW5CM9rIU+ahIpqA==
        //Kq7y8oSCe3Gwjo+eo9je8w==
    }

}
