package com.accommodation.test;

import com.accommodation.dao.AccommodationDao;
import com.accommodation.model.PersonalAccommodation;
import org.junit.Test;

import java.text.ParseException;

public class AccommodationTest {
    @Test
    public void uploadBasicPersonal() throws ParseException {
        AccommodationDao dao = new AccommodationDao();
        PersonalAccommodation personalAccommodation = new PersonalAccommodation();
        personalAccommodation.setStartDateString("10/11/2019");
        personalAccommodation.setEndDateString("11/11/2019");
        personalAccommodation.setTitle("so sad");
        personalAccommodation.setPricePerDay(213.2);
        int count = 1;
        System.out.println(count);
    }


}
