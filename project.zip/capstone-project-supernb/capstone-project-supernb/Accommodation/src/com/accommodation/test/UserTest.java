package com.accommodation.test;

import com.accommodation.dao.OrderDao;
import com.accommodation.dao.UserDao;
import com.accommodation.model.IndividualUser;
import com.accommodation.model.User;
import org.junit.Test;

public class UserTest {
    @Test
    public void testSecondSignUp(){
        UserDao user = new UserDao();
        IndividualUser inputUser = new IndividualUser();
        inputUser.setUserName("userName");
        inputUser.setAddress("dflkagjkesjhgtr");
        inputUser = user.signupsecond(inputUser);
        System.out.println(inputUser);
    }

    @Test
    public void testUpdateUserBasic(){
        UserDao dao = new UserDao();
        User inputUser = new User();
        inputUser.setUserName("abc");
        inputUser.setPassword("bbbbbbbb");

        User outputUser = dao.updateBasicInformation(inputUser);
        System.out.println(outputUser.toString());
    }

    @Test
    public void testUpdateUser(){
        UserDao dao = new UserDao();
        IndividualUser inputUser = new IndividualUser();
        inputUser.setUserName("abcdefg");
        inputUser.setAddress("aaaaaaaaaa");
        inputUser.setCardName("hhhhhh");
        inputUser.setCardNum("12142354365");
        inputUser.setSalutation("male");

        User outputUser = dao.updateInformation(inputUser);
        System.out.println(outputUser.toString());
    }

    @Test
    public void testRate(){
        UserDao userDao = new UserDao();
        OrderDao orderDao = new OrderDao();
        Integer rate = 5;

        IndividualUser inputUser = new IndividualUser();
        inputUser.setUserName("abc");
        inputUser = userDao.displayInformation(inputUser);

        int count = userDao.giveRate(rate, inputUser);

        System.out.println(count);
    }

}
