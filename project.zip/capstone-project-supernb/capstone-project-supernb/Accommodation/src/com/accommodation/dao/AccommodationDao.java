package com.accommodation.dao;

import com.accommodation.model.Accommodation;
import com.accommodation.model.CompanyAccommodation;
import com.accommodation.model.PersonalAccommodation;
import com.accommodation.model.User;
import com.accommodation.utils.DruidUtils;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;

import java.util.List;

public class AccommodationDao {
    private JdbcTemplate template = new JdbcTemplate(DruidUtils.getDataSource());

    //Give an accommodationID return full information of this accommodation
    public Accommodation concreteAccommodation(Accommodation inputAccommodation){
        try {
            String sql = "select * from accommodation where accommodationID = ? and whetherComplete = ?";
            Accommodation returnAccommodation = template.queryForObject(sql,  new BeanPropertyRowMapper<Accommodation>(Accommodation.class), inputAccommodation.getAccommodationID(), 0);
            return returnAccommodation;
        } catch (DataAccessException e) {
            e.printStackTrace();
            return null;
        }
    }
    public Accommodation concreteAccommodationAll(Accommodation inputAccommodation){
        try {
            String sql = "select * from accommodation where accommodationID = ?";
            Accommodation returnAccommodation = template.queryForObject(sql,  new BeanPropertyRowMapper<Accommodation>(Accommodation.class), inputAccommodation.getAccommodationID());
            return returnAccommodation;
        } catch (DataAccessException e) {
            e.printStackTrace();
            return null;
        }
    }

    public CompanyAccommodation concreteCompanyAccommodationAll(Accommodation inputAccommodation){
        try {
            String sql = "select * from accommodation where accommodationID = ?";
            CompanyAccommodation returnCompanyAccommodation = template.queryForObject(sql, new BeanPropertyRowMapper<CompanyAccommodation>(CompanyAccommodation.class),inputAccommodation.getAccommodationID());
            return returnCompanyAccommodation;
        } catch (DataAccessException e) {
            e.printStackTrace();
            return null;
        }
    }

    public CompanyAccommodation concreteCompanyAccommodation(Accommodation inputAccommodation){
        try {
            String sql = "select * from accommodation where accommodationID = ? and whetherComplete = ?";
            CompanyAccommodation returnCompanyAccommodation = template.queryForObject(sql, new BeanPropertyRowMapper<CompanyAccommodation>(CompanyAccommodation.class),inputAccommodation.getAccommodationID(), 0);
            return returnCompanyAccommodation;
        } catch (DataAccessException e) {
            e.printStackTrace();
            return null;
        }
    }

    public PersonalAccommodation concretePersonalAccommodationAll(Accommodation inputAccommodation){
        try {
            String sql = "select * from accommodation where accommodationID = ?";
            PersonalAccommodation returnPersonalAccommodation = template.queryForObject(sql, new BeanPropertyRowMapper<PersonalAccommodation>(PersonalAccommodation.class),inputAccommodation.getAccommodationID());
            return returnPersonalAccommodation;
        } catch (DataAccessException e) {
            e.printStackTrace();
            return null;
        }
    }

    public PersonalAccommodation concretePersonalAccommodation(Accommodation inputAccommodation){
        try {
            String sql = "select * from accommodation where accommodationID = ? and whetherComplete = ?";
            PersonalAccommodation returnPersonalAccommodation = template.queryForObject(sql, new BeanPropertyRowMapper<PersonalAccommodation>(PersonalAccommodation.class),inputAccommodation.getAccommodationID(), 0);
            return returnPersonalAccommodation;
        } catch (DataAccessException e) {
            e.printStackTrace();
            return null;
        }
    }

    public int uploadPersonalAccommodation(PersonalAccommodation inputAccommodation, String image0, String image1, String image2, String image3, String image4, String image5, String image6, String image7, String image8){
        String sql = "insert into accommodation(title, pricePerDay, city, address, suburb, postCode, startDate, " +
                "                               endDate, startDateString, endDateString, pet, userName, guestNum, " +
                "                               description, accommodationType, structureType, rentType, bedroom, " +
                "                               bathroom, kitchen, park, gym, wifi, lift, television,photoPath0,photoPath1,photoPath2,photoPath3,photoPath4,photoPath5,photoPath6,photoPath7,photoPath8) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        int count = template.update(sql, inputAccommodation.getTitle(),inputAccommodation.getPricePerDay(),inputAccommodation.getCity(),inputAccommodation.getAddress(),inputAccommodation.getSuburb(),
                                            inputAccommodation.getPostCode(),inputAccommodation.getStartDate(),inputAccommodation.getEndDate(),inputAccommodation.getStartDateString(),inputAccommodation.getEndDateString(),
                                            inputAccommodation.getPet(), inputAccommodation.getUserName(),inputAccommodation.getGuestNum(),inputAccommodation.getDescription(),inputAccommodation.getAccommodationType(),
                                            inputAccommodation.getStructureType(),inputAccommodation.getRentType(),inputAccommodation.getBedroom(),inputAccommodation.getBathroom(),inputAccommodation.getKitchen(),
                                            inputAccommodation.getPark(),inputAccommodation.getGym(),inputAccommodation.getWifi(),inputAccommodation.getLift(),inputAccommodation.getTelevision(),image0,image1,image2,image3,image4,image5,image6,image7,image8);
        return count;
    }

    public int uploadCompanyAccommodation(CompanyAccommodation inputAccommodation, String image0, String image1, String image2, String image3, String image4, String image5, String image6, String image7, String image8){
        String sql = "insert into accommodation(title, pricePerDay, city, address, suburb, postCode, startDate, " +
                "                               endDate, startDateString, endDateString, pet, userName, guestNum, " +
                "                               description, accommodationType, hotelType, star, url,photoPath0,photoPath1,photoPath2,photoPath3,photoPath4,photoPath5,photoPath6,photoPath7,photoPath8) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        int count = template.update(sql,inputAccommodation.getTitle(),inputAccommodation.getPricePerDay(),inputAccommodation.getCity(),inputAccommodation.getAddress(),inputAccommodation.getSuburb(),
                inputAccommodation.getPostCode(),inputAccommodation.getStartDate(),inputAccommodation.getEndDate(),inputAccommodation.getStartDateString(),inputAccommodation.getEndDateString(),
                inputAccommodation.getPet(), inputAccommodation.getUserName(),inputAccommodation.getGuestNum(),inputAccommodation.getDescription(),inputAccommodation.getAccommodationType(),inputAccommodation.getHotelType(), inputAccommodation.getStar(), inputAccommodation.getUrl(),image0,image1,image2,image3,image4,image5,image6,image7,image8);
        return count;
    }


    public List<Accommodation> postItem(String userName){
        try {
            String sql = "select * from accommodation where userName = ? and whetherComplete <> ?";
            List<Accommodation> returnList = template.query(sql, new BeanPropertyRowMapper<Accommodation>(Accommodation.class),userName, 2);
            return returnList;
        } catch (DataAccessException e) {
            e.printStackTrace();
            return null;
        }
    }

    public List<Accommodation> searchFirst(Accommodation accommodation){
        try {
            String location = accommodation.getCity();
            location = '%'+location+'%';
            String sql = "select * from accommodation where (city like ? or suburb like ? or description like ? or address like ?) and whetherComplete = ?";
            List<Accommodation> mediumList = template.query(sql,  new BeanPropertyRowMapper<Accommodation>(Accommodation.class),location,location,location,location, 0);
            System.out.println("lololol"+ mediumList.toString());
            return mediumList;
        } catch (DataAccessException e) {
            e.printStackTrace();
            return null;
        }
    }

    public List<Accommodation> searchSecond(Accommodation accommodation, String lowOrHigh){
        try {
            String location = accommodation.getCity();
            location = '%'+location+'%';
            String sql = "select * from accommodation where city like ? or suburb like ? or description like ? and whetherComplete = ?order by pricePerDay ?";
            List<Accommodation> mediumList = template.query(sql,  new BeanPropertyRowMapper<Accommodation>(Accommodation.class),location,location,location,0, lowOrHigh);
            return mediumList;
        } catch (DataAccessException e) {
            e.printStackTrace();
            return null;
        }
    }

    public List<CompanyAccommodation> searchSecondCompany(CompanyAccommodation accommodation, String lowOrHigh){
        try {
            String location = accommodation.getCity();
            location = '%'+location+'%';
            String sql = null;
            if(lowOrHigh.equals("asc")){
                sql = "select * from accommodation where (accommodationType = ?) and (city like ? or suburb like ? or description like ? or address like ?) and whetherComplete = ? order by pricePerDay asc";
            }
            else{
                sql = "select * from accommodation where (accommodationType = ?) and (city like ? or suburb like ? or description like ? or address like ?) and whetherComplete = ? order by pricePerDay desc";
            }
            List<CompanyAccommodation> mediumList = template.query(sql,  new BeanPropertyRowMapper<CompanyAccommodation>(CompanyAccommodation.class),"Company Accommodation",location,location,location,location,0);
            return mediumList;
        } catch (DataAccessException e) {
            e.printStackTrace();
            return null;
        }
    }

    public List<PersonalAccommodation> searchSecondPersonal(PersonalAccommodation accommodation, String lowOrHigh){
        try {
            String location = accommodation.getCity();
            location = '%'+location+'%';
            String sql = null;
            if(lowOrHigh.equals("asc")){
                sql = "select * from accommodation where (accommodationType = ?) and (city like ? or suburb like ? or description like ? or address like ?) and whetherComplete = ? order by pricePerDay asc";
            }
            else{
                sql = "select * from accommodation where (accommodationType = ?) and (city like ? or suburb like ? or description like ? or address like ?) and whetherComplete = ? order by pricePerDay desc";
            }
            List<PersonalAccommodation> mediumList = template.query(sql,  new BeanPropertyRowMapper<PersonalAccommodation>(PersonalAccommodation.class),"Personal Accommodation",location,location,location,location,0);
            return mediumList;
        } catch (DataAccessException e) {
            e.printStackTrace();
            return null;
        }
    }

    public void deleteAccommodation(Integer accommodationID){
        String sql = "update accommodation set whetherComplete = ? where accommodationID = ?";
        int count = template.update(sql, 2, accommodationID);
    }

}
