package com.accommodation.dao;

import com.accommodation.model.IndividualUser;
import com.accommodation.model.User;
import com.accommodation.utils.DruidUtils;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;

public class UserDao {
    private JdbcTemplate template = new JdbcTemplate(DruidUtils.getDataSource());

    // check whether username is valid
    public User checkusername(User signUpUser){
        try {
            String sql = "select * from user where userName= ? ";
            User user = template.queryForObject(sql, new BeanPropertyRowMapper<User>(User.class),signUpUser.getUserName());
            return user;
        } catch (EmptyResultDataAccessException e) {
            e.printStackTrace();
            return null;
        }
    }

    // First step, return a user
    public User signupfirst(User signUpUser){
        String sql = "insert into user values (?,?)";
        int count = template.update(sql, signUpUser.getUserName(),signUpUser.getPassword());
        sql = "insert into individualuser(userName) values (?)";
        count = template.update(sql, signUpUser.getUserName());
        try {
            sql = "select * from user where userName= ?";
            User user = template.queryForObject(sql, new BeanPropertyRowMapper<User>(User.class),signUpUser.getUserName());
            return user;
        } catch (DataAccessException e) {
            e.printStackTrace();
            return null;
        }
    }

    // Second signUp step
    public IndividualUser signupsecond(IndividualUser signUpUser){
        String sql = "update individualuser set salutation = ?, gender = ?, firstName = ?, lastName = ?, email = ?, phoneContact = ?, zip = ?, state = ?, address = ?, country = ? where userName = ?";
        int count = template.update(sql, signUpUser.getSalutation(),signUpUser.getGender(),signUpUser.getFirstName(),
                                            signUpUser.getLastName(),signUpUser.getEmail(),signUpUser.getPhoneContact(),
                                            signUpUser.getZip(),signUpUser.getState(),signUpUser.getAddress(),signUpUser.getCountry(),signUpUser.getUserName());
        try {
            sql = "select * from individualuser where userName = ?";
            IndividualUser user = template.queryForObject(sql, new BeanPropertyRowMapper<IndividualUser>(IndividualUser.class),signUpUser.getUserName());
            return user;
        } catch (DataAccessException e) {
            e.printStackTrace();
            return null;
        }
    }

    // Third signUp step
    public  IndividualUser signupthird(IndividualUser signUpUser){
        String sql = "update individualuser set cardType = ?, cardNum = ?, cvc = ?, cardName = ?, expireMonth = ?, expireYear = ?";
        int count = template.update(sql, signUpUser.getCardType(), signUpUser.getCardNum(), signUpUser.getCvc(),signUpUser.getCardName(),signUpUser.getExpireMonth(),signUpUser.getExpireYear());
        try {
            sql = "select * from individualuser where userName = ?";
            IndividualUser user = template.queryForObject(sql, new BeanPropertyRowMapper<IndividualUser>(IndividualUser.class),signUpUser.getUserName());
            return user;
        } catch (DataAccessException e) {
            e.printStackTrace();
            return null;
        }
    }

    // check login
    public User login(User loginUser) {
        try {
//            String afterencrypted = EncUtils.encryptString(loginUser.getPassword());
//            String sql = "select * from auctionuser where userID= ? and password = ?";
//            User user = template.queryForObject(sql, new BeanPropertyRowMapper<User>(User.class),loginUser.getUserID(),afterencrypted);
//            return user;
            String sql = "select * from user where userName= ? and password = ?";
            User user = template.queryForObject(sql, new BeanPropertyRowMapper<User>(User.class),loginUser.getUserName(),loginUser.getPassword());
            return user;
        } catch (Exception e) {
            e.printStackTrace();
            // If no results, then return null
            return null;
        }
    }

    // update user information
    public IndividualUser updateInformation(IndividualUser inputUser){
        String sql = "update individualuser set salutation = ?, gender = ?, firstName = ?, lastName = ?, email = ?, phoneContact = ?, zip = ?, state = ?, address = ?, country = ?, cardType = ?, cardNum = ?, cvc = ?, cardName = ?, expireMonth = ?, expireYear = ?, rate = ?, commentTimes = ? where userName = ?";
        int count = template.update(sql, inputUser.getSalutation(), inputUser.getGender(),inputUser.getFirstName()
                                                     , inputUser.getLastName(), inputUser.getEmail(), inputUser.getPhoneContact()
                                                     , inputUser.getZip(), inputUser.getState(), inputUser.getAddress(), inputUser.getCountry(), inputUser.getCardType(), inputUser.getCardNum(), inputUser.getCvc(), inputUser.getCardName(), inputUser.getExpireMonth(), inputUser.getExpireYear(), inputUser.getRate(), inputUser.getCommentTimes(), inputUser.getUserName());
        try {
            sql = "select * from individualuser where userName= ?";
            IndividualUser returnUser = template.queryForObject(sql, new BeanPropertyRowMapper<IndividualUser>(IndividualUser.class), inputUser.getUserName());
            return returnUser;
        } catch (DataAccessException e) {
            e.printStackTrace();
            return null;
        }
    }

    // update user password
    public User updateBasicInformation(User user){
        String sql = "update user set password = ? where userName = ?";
        int count = template.update(sql, user.getPassword(), user.getUserName());
        try {
            sql = "select * from user where userName = ?";
            User returnUser = template.queryForObject(sql, new BeanPropertyRowMapper<User>(User.class), user.getUserName());
            return returnUser;
        } catch (DataAccessException e) {
            e.printStackTrace();
            return null;
        }
    }

    public IndividualUser displayInformation(IndividualUser inputUser){
        try {
            String sql = "select * from individualuser where userName = ?";
            IndividualUser returnUser = template.queryForObject(sql, new BeanPropertyRowMapper<IndividualUser>(IndividualUser.class), inputUser.getUserName());
            return returnUser;
        } catch (DataAccessException e) {
            e.printStackTrace();
            return null;
        }
    }

    public int giveRate(Integer rateNumber, IndividualUser seller){
        Double totalRate = seller.getRate();
        Integer commentTimes = seller.getCommentTimes();
        Integer newCommentTimes = commentTimes + 1;
        totalRate = (totalRate + rateNumber*commentTimes)/newCommentTimes;

        String sql = "update individualuser set rate = ?, commentTimes = ? where userName = ?";
        int count = template.update(sql, totalRate, commentTimes, seller.getUserName());
        return count;
    }

}
