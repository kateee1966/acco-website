package com.accommodation.dao;

import com.accommodation.model.Accommodation;
import com.accommodation.model.Order;
import com.accommodation.utils.DruidUtils;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;

import java.util.Date;
import java.util.List;

public class OrderDao  {
    private JdbcTemplate template = new JdbcTemplate(DruidUtils.getDataSource());

    public boolean checkValidOrder(Order inputOrder){
        Accommodation returnAccommodation = null;
        try {
            String sql = "select * from accommodation where accommodationID = ?";
            returnAccommodation = template.queryForObject(sql, new BeanPropertyRowMapper<Accommodation>(Accommodation.class), inputOrder.getAccommodationID());
        } catch (DataAccessException e) {
            e.printStackTrace();
        }
        if (returnAccommodation.getWhetherComplete()==1){
            return false;
        }
        return true;
    }

    public boolean checkValidDate(Order inputOrder){
        Accommodation returnAccommodation = null;
        try {
            String sql = "select * from accommodation where accommodationID = ?";
            returnAccommodation = template.queryForObject(sql, new BeanPropertyRowMapper<Accommodation>(Accommodation.class), inputOrder.getAccommodationID());
        } catch (DataAccessException e) {
            e.printStackTrace();
            returnAccommodation = null;
        }
        Date start = inputOrder.getStartDate();
        Date end = inputOrder.getEndDate();

        if(start.before(returnAccommodation.getStartDate()) || end.after(returnAccommodation.getEndDate())){
            return false;
        }
        return true;
    }

    public boolean checkValidGuest(Order inputOrder){
        Accommodation returnAccommodation = null;
        try {
            String sql = "select * from accommodation where accommodationID = ?";
            returnAccommodation = template.queryForObject(sql, new BeanPropertyRowMapper<Accommodation>(Accommodation.class), inputOrder.getAccommodationID());
        } catch (DataAccessException e) {
            e.printStackTrace();
            returnAccommodation = null;
        }
        int guest = inputOrder.getGuestNumber();

        if(guest > returnAccommodation.getGuestNum()){
            return false;
        }

        return true;
    }

    public Order insertNewOrder(Order inputOrder){
        String sql = "insert into accommodationorder(accommodationID, sellerName, buyerName, orderCreatedDate, startDate, endDate, guestNumber, amount, orderCreatedDateString, startDateString, endDateString) values (?,?,?,?,?,?,?,?,?,?,?)";
        int count = template.update(sql, inputOrder.getAccommodationID(), inputOrder.getSellerName(), inputOrder.getBuyerName(), inputOrder.getOrderCreatedDate(),
                                    inputOrder.getStartDate(), inputOrder.getEndDate(), inputOrder.getGuestNumber(), inputOrder.getAmount(), inputOrder.getOrderCreatedDateString(), inputOrder.getStartDateString(), inputOrder.getEndDateString());
        sql = "update accommodation set whetherComplete = ? where accommodationID = ?";
        count = template.update(sql, 1, inputOrder.getAccommodationID());
        sql = "select * from accommodationorder where accommodationID = ?";
        Order returnOrder = template.queryForObject(sql, new BeanPropertyRowMapper<Order>(Order.class), inputOrder.getAccommodationID());
        return returnOrder;
    }

    public Order displayOrder(Order inputOrder){
        try {
            String sql = "select * from accommodationorder where OrderID = ?";
            Order returnOrder = template.queryForObject(sql, new BeanPropertyRowMapper<Order>(Order.class), inputOrder.getOrderID());
            return returnOrder;
        } catch (DataAccessException e) {
            e.printStackTrace();
            return null;
        }
    }

    public int updateOrder(Order inputOrder){
        String sql = "update accommodationorder set whetherRate = ? where OrderID = ?";
        int count = template.update(sql, 1, inputOrder.getOrderID());
        return count;
    }

    public List<Order> postOrder(String userName){
        try {
            String sql = "select * from accommodationorder where sellerName = ?";
            List<Order> returnList = template.query(sql, new BeanPropertyRowMapper<Order>(Order.class), userName);
            return returnList;
        } catch (DataAccessException e) {
            e.printStackTrace();
            return null;
        }
    }

    public List<Order> boughtOrder(String userName){
        try {
            String sql = "select * from accommodationorder where buyerName = ?";
            List<Order> returnList = template.query(sql, new BeanPropertyRowMapper<Order>(Order.class), userName);
            return returnList;
        } catch (DataAccessException e) {
            e.printStackTrace();
            return null;
        }
    }

}
