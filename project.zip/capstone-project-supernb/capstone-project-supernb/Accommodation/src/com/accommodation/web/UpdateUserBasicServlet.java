package com.accommodation.web;

import com.accommodation.dao.UserDao;
import com.accommodation.model.User;
import com.accommodation.test.EncTest;
import com.accommodation.utils.EncUtils;
import net.sf.json.JSONObject;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Map;

/**
 * Input: userName, password
 * Output: returnuser; state means success
 */
@WebServlet("/UpdateUserBasicServlet")
public class UpdateUserBasicServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        Map<String, String[]> map = request.getParameterMap();
        User inputUser = new User();
        inputUser.setUserName(request.getParameter("userName"));
        inputUser.setPassword(request.getParameter("oldPassword"));

        UserDao dao = new UserDao();
        JSONObject json = new JSONObject();

        User checkUser = dao.login(inputUser);
        if(checkUser == null){
            User returnUser = dao.updateBasicInformation(inputUser);
            json.put("state", 0);
            json.put("returnUser", returnUser);
        }
        else{
            try {
                inputUser.setPassword(EncUtils.encryptString(request.getParameter("newPassword")));
            } catch (Exception e) {
                e.printStackTrace();
            }
            User returnUser = dao.updateBasicInformation(inputUser);
            json.put("state", 1);
            json.put("returnUser", returnUser);
        }

        response.getWriter().write(json.toString());

    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request, response);
    }
}
