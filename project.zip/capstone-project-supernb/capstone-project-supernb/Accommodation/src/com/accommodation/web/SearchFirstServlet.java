package com.accommodation.web;

import com.accommodation.dao.AccommodationDao;
import com.accommodation.model.Accommodation;
import net.sf.json.JSONObject;
import org.apache.commons.beanutils.BeanUtils;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@WebServlet("/SearchFirstServlet")
public class SearchFirstServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        Map<String, String[]> map = request.getParameterMap();
// --------------------------------------------------------------------------------------------------------------------------
        String location = request.getParameter("location");
        ArrayList<String> allLocationString = new ArrayList<String>();
        for (String str : location.split("%20")) {
            allLocationString.add(str);
        }

        String datefilter = request.getParameter("datefilter");
        ArrayList<String> allDateString = new ArrayList<String>();
        for (String str : datefilter.split(" - ")) {
            allDateString.add(str);
        }

        String startDateString = allDateString.get(0);
        String endDateString = allDateString.get(1);
// --------------------------------------------------------------------------------------------------------------------------
        AccommodationDao dao = new AccommodationDao();
// ------------------------------------------------------------------------------------------------------------------------
        Accommodation inputAccommodation = new Accommodation();
        try {
            BeanUtils.populate(inputAccommodation, map);
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        }
        try {
            inputAccommodation.setStartDateString(startDateString);
            inputAccommodation.setEndDateString(endDateString);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        List<Accommodation> firstList = new ArrayList<Accommodation>();
        List<Accommodation> secondList = new ArrayList<Accommodation>();
        List<Accommodation> finalList = new ArrayList<Accommodation>();
// ------------------------------------------------------------------------------------------------------------------------
        for(String str: allLocationString){
            inputAccommodation.setCity(str);
            System.out.println(inputAccommodation.toString());
            firstList.addAll(dao.searchFirst(inputAccommodation));
        }
        for(Accommodation acc : firstList){
            if(acc.getGuestNum() >= inputAccommodation.getGuestNum() && acc.getEndDate().after(inputAccommodation.getEndDate()) && acc.getStartDate().before(inputAccommodation.getStartDate())){
                secondList.add(acc);
            }
        }
        if(secondList.size()==1){
            finalList.add(secondList.get(0));
        }
        for(int i = 0; i<secondList.size() -1 ; i++){
            int flag = 0;
            for(int j=i+1; j<secondList.size(); j++){
                if(secondList.get(i).getAccommodationID().equals(secondList.get(j).getAccommodationID()) && i!=j ){
                    flag = 1;
                }
            }
            if(flag == 0){
                finalList.add(secondList.get(i));
            }
        }
        if(secondList.size()>1){
            finalList.add(secondList.get(secondList.size()-1));
        }
// ------------------------------------------------------------------------------------------------------------------------
        JSONObject json = new JSONObject();
        json.put("state", 1);
        json.put("returnList", finalList);

        response.getWriter().write(json.toString());
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request, response);
    }
}
