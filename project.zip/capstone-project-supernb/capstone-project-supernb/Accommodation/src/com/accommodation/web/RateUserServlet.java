package com.accommodation.web;

import com.accommodation.dao.OrderDao;
import com.accommodation.dao.UserDao;
import com.accommodation.model.IndividualUser;
import com.accommodation.model.Order;
import net.sf.json.JSONObject;
import org.apache.commons.beanutils.BeanUtils;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.Map;

@WebServlet("/RateUserServlet")
public class RateUserServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        Map<String, String[]> map = request.getParameterMap();
        String rate = request.getParameter("rate");
        Integer rateNumber = Integer.parseInt(rate);

        Order inputOrder = new Order();
        IndividualUser inputUser = new IndividualUser();

        try {
            BeanUtils.populate(inputOrder, map);
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        }

        OrderDao dao = new OrderDao();
        UserDao userdao = new UserDao();

        JSONObject json = new JSONObject();

        Order returnOrder = dao.displayOrder(inputOrder);
        inputUser.setUserName(returnOrder.getSellerName());

        int validOrder = 1;
        int notRateYet = 1;
        int successfulRate = 1;

        if(returnOrder == null){
            validOrder  = 0;
        }
        else if(returnOrder.getWhetherRate() == 1){
            notRateYet = 0;
        }
        else{
            IndividualUser seller = userdao.displayInformation(inputUser);
            int count = userdao.giveRate(rateNumber, seller);
            if(count != 1){
                successfulRate = 0;
            }
            else{
                int orderCount = dao.updateOrder(returnOrder);
            }
        }


        json.put("state1", validOrder);
        json.put("state2", notRateYet);
        json.put("state3", successfulRate);
        json.put("order", inputOrder);
        System.out.println("rate user:"+json.toString());

        response.getWriter().write(json.toString());
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request, response);
    }
}
