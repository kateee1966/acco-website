package com.accommodation.web;

import com.accommodation.model.CommonVars;
import net.sf.json.JSONObject;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

/**
 * Input : no input
 * Output :
 */

@WebServlet("/LogOutServlet")
public class LogOutServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession httpSession = request.getSession();
        if (httpSession.getAttribute(CommonVars.SESSION_LOGIN_KEY) != null) {
            httpSession.removeAttribute(CommonVars.SESSION_LOGIN_KEY);
        }
        JSONObject json = new JSONObject();
        json.put("state", 1);
        json.put("isLoginOut", 1);
        response.getWriter().write(json.toString());
        response.getWriter().flush();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request, response);
    }
}
