package com.accommodation.web;

import com.accommodation.dao.AccommodationDao;
import com.accommodation.dao.UserDao;
import com.accommodation.model.Accommodation;
import com.accommodation.model.CompanyAccommodation;
import com.accommodation.model.IndividualUser;
import com.accommodation.model.PersonalAccommodation;
import net.sf.json.JSONObject;
import org.apache.commons.beanutils.BeanUtils;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.Map;

@WebServlet("/ConcreteAccommodationAllServlet")
public class ConcreteAccommodationAllServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        Map<String, String[]> map = request.getParameterMap();
        Accommodation inputAccommodation = new Accommodation();

        try {
            BeanUtils.populate(inputAccommodation, map);
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        }


        AccommodationDao dao = new AccommodationDao();
        UserDao udao = new UserDao();

        Accommodation returnAccommodation = dao.concreteAccommodationAll(inputAccommodation);
        CompanyAccommodation returnCompanyAccommodation = new CompanyAccommodation();
        PersonalAccommodation returnPersonalAccommodation = new PersonalAccommodation();
        IndividualUser owner = new IndividualUser();

        if(returnAccommodation!=null && returnAccommodation.getAccommodationType().equals("Company Accommodation")){
            returnCompanyAccommodation = dao.concreteCompanyAccommodationAll(inputAccommodation);
            String ownerName = returnCompanyAccommodation.getUserName();
            IndividualUser inputUser = new IndividualUser();
            inputUser.setUserName(ownerName);
            owner = udao.displayInformation(inputUser);
        }
        else if(returnAccommodation!=null){
            returnPersonalAccommodation = dao.concretePersonalAccommodationAll(inputAccommodation);
            String ownerName = returnPersonalAccommodation.getUserName();
            IndividualUser inputUser = new IndividualUser();
            inputUser.setUserName(ownerName);
            owner = udao.displayInformation(inputUser);
        }


        JSONObject json = new JSONObject();

        if(returnAccommodation == null){
            json.put("state", 0);
            json.put("accommodation", returnAccommodation);
            json.put("owner", owner);
        }
        else{
            if(returnAccommodation.getAccommodationType().equals("Company Accommodation")){
                json.put("state", 1);
                json.put("accommodation", returnCompanyAccommodation);
                json.put("owner", owner);
            }
            else{
                json.put("state", 2);
                json.put("accommodation", returnPersonalAccommodation);
                json.put("owner", owner);
            }
        }
        response.getWriter().write(json.toString());
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request, response);
    }
}
