package com.accommodation.web;

import com.accommodation.dao.OrderDao;
import com.accommodation.model.Order;
import net.sf.json.JSONObject;
import org.apache.commons.beanutils.BeanUtils;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Map;

/**
 * Input: startDate, endDate, guestNumber, sellerName, buyerName, amount, accommodationID
 *  Output : order
 */
@WebServlet("/MakeOrderServlet")
public class MakeOrderServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        Map<String, String[]> map = request.getParameterMap();
        Order newOrder = new Order();

        String inputDate = request.getParameter("inputDate");
        System.out.println(inputDate);
        ArrayList<String> allString = new ArrayList<String>();
        for (String str : inputDate.split(" - ")) {
            allString.add(str);
        }

        String startDateString = allString.get(0);
        String endDateString = allString.get(1);

        try {
            BeanUtils.populate(newOrder, map);
            Date current = new Date();
            newOrder.setOrderCreatedDate(current);
            newOrder.setStartDateString(startDateString);
            newOrder.setEndDateString(endDateString);
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        } catch (ParseException e) {
            e.printStackTrace();
        }

        OrderDao dao = new OrderDao();
        JSONObject json = new JSONObject();

        int checkGuest = 100;
        int checkDate = 100;
        int checkOrder = 100;

        if(!dao.checkValidGuest(newOrder)){
            checkGuest = 0;
        }
        else{
            checkGuest = 1;
        }

        if(!dao.checkValidDate(newOrder)){
            checkDate = 0;
        }
        else{
            checkDate = 1;
        }

        if(!dao.checkValidOrder(newOrder)){
            checkOrder = 0;
        }
        else{
            checkOrder = 1;
        }

        json.put("state1", checkGuest);
        json.put("state2", checkDate);
        json.put("state3", checkOrder);
        System.out.println(checkDate);
        System.out.println(checkGuest);
        System.out.println(checkOrder);
        Order returnOrder = null;
        if(checkGuest == 1 && checkDate == 1 && checkOrder == 1){
            returnOrder = dao.insertNewOrder(newOrder);
            System.out.println("hahahahahahahahshsabishabi");
        }

        json.put("returnOrder", returnOrder);

        System.out.println(json.toString());

        response.getWriter().write(json.toString());
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request, response);
    }
}
