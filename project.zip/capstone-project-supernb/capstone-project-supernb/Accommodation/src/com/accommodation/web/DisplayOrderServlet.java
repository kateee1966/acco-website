package com.accommodation.web;

import com.accommodation.dao.AccommodationDao;
import com.accommodation.dao.OrderDao;
import com.accommodation.model.Accommodation;
import com.accommodation.model.CompanyAccommodation;
import com.accommodation.model.Order;
import com.accommodation.model.PersonalAccommodation;
import net.sf.json.JSONObject;
import org.apache.commons.beanutils.BeanUtils;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.Map;

/**
 *  Input : OrderID
 *  Output : state: 1 means success, 0 means can not find this order.
 *          order : return order
 */
@WebServlet("/DisplayOrderServlet")
public class DisplayOrderServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        Map<String, String[]> map = request.getParameterMap();

        Order newOrder = new Order();
        try {
            BeanUtils.populate(newOrder, map);
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        }

        OrderDao dao = new OrderDao();
        AccommodationDao aDao = new AccommodationDao();
        Accommodation outputAccommodation = new Accommodation();
        CompanyAccommodation outputCompanyAccommodation = new CompanyAccommodation();
        PersonalAccommodation outputPersonalAccommodation = new PersonalAccommodation();
        JSONObject json = new JSONObject();

        Order returnOrder = new Order();
        returnOrder = dao.displayOrder(newOrder);

        if(returnOrder != null){
            json.put("state", 1);
            json.put("order", returnOrder);
            int accommodationID = returnOrder.getAccommodationID();
            Accommodation inputAccommodation = new Accommodation();
            inputAccommodation.setAccommodationID(accommodationID);
            outputAccommodation = aDao.concreteAccommodationAll(inputAccommodation);
            if(outputAccommodation.getAccommodationType().equals("Company Accommodation")){
                outputCompanyAccommodation = aDao.concreteCompanyAccommodationAll(inputAccommodation);
            }
            else{
                outputPersonalAccommodation = aDao.concretePersonalAccommodationAll(inputAccommodation);
            }

            if(outputAccommodation.getAccommodationType().equals("Company Accommodation")){
                json.put("accommodation", outputCompanyAccommodation);
            }
            else{
                json.put("accommodation", outputPersonalAccommodation);
            }
        }
        else{
            json.put("state", 0);
        }

        response.getWriter().write(json.toString());
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request, response);
    }
}
