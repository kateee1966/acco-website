package com.accommodation.web;

import com.accommodation.dao.AccommodationDao;
import com.accommodation.model.CompanyAccommodation;
import com.accommodation.model.PersonalAccommodation;
import net.sf.json.JSONObject;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileItemFactory;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.lang.RandomStringUtils;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

@WebServlet("/UploadBasicServlet")
public class UploadBasicServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        AccommodationDao dao = new AccommodationDao();
        int validDate = 1;
        int count = 1;

        JSONObject json = new JSONObject();

        FileItemFactory factory = new DiskFileItemFactory();
        ServletFileUpload upload = new ServletFileUpload(factory);

        List items = null;
        try {
            items = upload.parseRequest(request);
        } catch (FileUploadException e) {
            e.printStackTrace();
        }

        String image0 = null;
        String image1 = null;
        String image2 = null;
        String image3 = null;
        String image4 = null;
        String image5 = null;
        String image6 = null;
        String image7 = null;
        String image8 = null;

        String accommodationType = "Company";
        Iterator checkAccommodationType = items.iterator();
        while(checkAccommodationType.hasNext()){
            FileItem item = (FileItem) checkAccommodationType.next();
            if(item.isFormField()){
                if(item.getFieldName().equals("accommodationType")){
                    accommodationType = item.getString();
                }
            }
        }


        if(accommodationType.equals("Company")){
            CompanyAccommodation companyAccommodation = new CompanyAccommodation();

            Iterator iter = items.iterator();
            while(iter.hasNext()){
                FileItem item = (FileItem) iter.next();

                if(item.isFormField()){

                    if(item.getFieldName().equals("title")){
                        companyAccommodation.setTitle(item.getString());
                    }

                    if(item.getFieldName().equals("pricePerDay")){
                        String pricePerDayString = item.getString();
                        Double pricePerDay = Double.parseDouble(pricePerDayString);
                        companyAccommodation.setPricePerDay(pricePerDay);
                    }

                    if(item.getFieldName().equals("city")){
                        companyAccommodation.setCity(item.getString());
                    }

                    if(item.getFieldName().equals("suburb")){
                        companyAccommodation.setSuburb(item.getString());
                    }

                    if(item.getFieldName().equals("address")){
                        companyAccommodation.setAddress(item.getString());
                    }

                    if(item.getFieldName().equals("postCode")){
                        String postCodeString = item.getString();
                        Integer postCode = Integer.parseInt(postCodeString);
                        companyAccommodation.setPostCode(postCode);
                    }

                    if(item.getFieldName().equals("datefilter")){
                        String datefilter = item.getString();
                        ArrayList<String> allDateString = new ArrayList<String>();
                        for (String str : datefilter.split(" - ")) {
                            allDateString.add(str);
                        }

                        String startDateString = allDateString.get(0);
                        String endDateString = allDateString.get(1);

                        try {
                            companyAccommodation.setStartDateString(startDateString);
                            companyAccommodation.setEndDateString(endDateString);
                        } catch (ParseException e) {
                            e.printStackTrace();
                        }
                    }

                    if(item.getFieldName().equals("pet")){
                        String petString = item.getString();
                        Integer pet = Integer.parseInt(petString);
                        companyAccommodation.setPet(pet);
                    }

                    if(item.getFieldName().equals("userName")){
                        companyAccommodation.setUserName(item.getString());
                    }

                    if(item.getFieldName().equals("guestNum")){
                        String guestNumString = item.getString();
                        Integer guestNum = Integer.parseInt(guestNumString);
                        companyAccommodation.setGuestNum(guestNum);
                    }

                    if(item.getFieldName().equals("description")){
                        companyAccommodation.setDescription(item.getString());
                    }

                    if(item.getFieldName().equals("accommodationType")){
                        companyAccommodation.setAccommodationType(item.getString());
                    }

                    if(item.getFieldName().equals("hotelType")){
                        companyAccommodation.setHotelType(item.getString());
                    }

                    if(item.getFieldName().equals("url")){
                        companyAccommodation.setUrl(item.getString());
                    }

                    if(item.getFieldName().equals("star")){
                        String starString = item.getString();
                        Integer star = Integer.parseInt(starString);
                        companyAccommodation.setStar(star);
                    }
                }
                else{
                    String randomName = RandomStringUtils.random(20, "abcdefghijklmnopqrstuvwxyz1234567890");
                    String fileName = item.getName();

                    int index = fileName.lastIndexOf("\\");
                    fileName = fileName.substring(index + 1);
                    fileName = randomName + fileName;
                    request.setAttribute("realFileName", fileName);

                    String basePath = "/Users/cannelloni/19s3/comp3900/project/capstone-project-supernb/Accommodation/out/artifacts/Accommodation_war_exploded/userimage";
                    String relativePath = "userimage/" + fileName;
                    File file = new File(basePath, fileName);

                    try {
                        item.write(file);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                    if(image0 == null){
                        image0 = relativePath;
                    }
                    else if(image1 == null){
                        image1 = relativePath;
                    }
                    else if(image2 == null){
                        image2 = relativePath;
                    }
                    else if(image3 == null){
                        image3 = relativePath;
                    }
                    else if(image4 == null){
                        image4 = relativePath;
                    }
                    else if(image5 == null){
                        image5 = relativePath;
                    }
                    else if(image6 == null){
                        image6 = relativePath;
                    }
                    else if(image7 == null){
                        image7 = relativePath;
                    }
                    else{
                        image8 = relativePath;
                    }
                }
            }

            if(companyAccommodation.getStartDate().after(companyAccommodation.getEndDate())){
                validDate = 0;
            }
            else{
                count = dao.uploadCompanyAccommodation(companyAccommodation,image0,image1,image2,image3,image4,image5,image6,image7,image8);
            }

            json.put("state1", validDate);
            json.put("state2", count);

        }
        else{
            PersonalAccommodation personalAccommodation = new PersonalAccommodation();

            Iterator iter = items.iterator();
            while(iter.hasNext()){
                FileItem item = (FileItem) iter.next();

                if(item.isFormField()){

                    if(item.getFieldName().equals("title")){
                        personalAccommodation.setTitle(item.getString());
                    }

                    if(item.getFieldName().equals("pricePerDay")){
                        String pricePerDayString = item.getString();
                        Double pricePerDay = Double.parseDouble(pricePerDayString);
                        personalAccommodation.setPricePerDay(pricePerDay);
                    }

                    if(item.getFieldName().equals("city")){
                        personalAccommodation.setCity(item.getString());
                    }

                    if(item.getFieldName().equals("suburb")){
                        personalAccommodation.setSuburb(item.getString());
                    }

                    if(item.getFieldName().equals("address")){
                        personalAccommodation.setAddress(item.getString());
                    }

                    if(item.getFieldName().equals("postCode")){
                        String postCodeString = item.getString();
                        Integer postCode = Integer.parseInt(postCodeString);
                        personalAccommodation.setPostCode(postCode);
                    }

                    if(item.getFieldName().equals("datefilter")){
                        String datefilter = item.getString();
                        ArrayList<String> allDateString = new ArrayList<String>();
                        for (String str : datefilter.split(" - ")) {
                            allDateString.add(str);
                        }

                        String startDateString = allDateString.get(0);
                        String endDateString = allDateString.get(1);

                        try {
                            personalAccommodation.setStartDateString(startDateString);
                            personalAccommodation.setEndDateString(endDateString);
                        } catch (ParseException e) {
                            e.printStackTrace();
                        }
                    }

                    if(item.getFieldName().equals("pet")){
                        String petString = item.getString();
                        Integer pet = Integer.parseInt(petString);
                        personalAccommodation.setPet(pet);
                    }

                    if(item.getFieldName().equals("userName")){
                        personalAccommodation.setUserName(item.getString());
                    }

                    if(item.getFieldName().equals("guestNum")){
                        String guestNumString = item.getString();
                        Integer guestNum = Integer.parseInt(guestNumString);
                        personalAccommodation.setGuestNum(guestNum);
                    }


                    if(item.getFieldName().equals("description")){
                        personalAccommodation.setDescription(item.getString());
                    }

                    if(item.getFieldName().equals("accommodationType")){
                        personalAccommodation.setAccommodationType(item.getString());
                    }

                    if(item.getFieldName().equals("structureType")){
                        personalAccommodation.setStructureType(item.getString());
                    }

                    if(item.getFieldName().equals("rentType")){
                        personalAccommodation.setRentType(item.getString());
                    }

                    if(item.getFieldName().equals("bedroom")){
                        String inputString= item.getString();
                        Integer inputInteger= Integer.parseInt(inputString);
                        personalAccommodation.setBedroom(inputInteger);
                    }

                    if(item.getFieldName().equals("bathroom")){
                        String inputString= item.getString();
                        Integer inputInteger= Integer.parseInt(inputString);
                        personalAccommodation.setBathroom(inputInteger);
                    }

                    if(item.getFieldName().equals("kitchen")){
                        String inputString= item.getString();
                        Integer inputInteger= Integer.parseInt(inputString);
                        personalAccommodation.setKitchen(inputInteger);
                    }

                    if(item.getFieldName().equals("park")){
                        String inputString= item.getString();
                        Integer inputInteger= Integer.parseInt(inputString);
                        personalAccommodation.setPark(inputInteger);
                    }

                    if(item.getFieldName().equals("gym")){
                        String inputString= item.getString();
                        Integer inputInteger= Integer.parseInt(inputString);
                        personalAccommodation.setGym(inputInteger);
                    }

                    if(item.getFieldName().equals("wifi")){
                        String inputString= item.getString();
                        Integer inputInteger= Integer.parseInt(inputString);
                        personalAccommodation.setWifi(inputInteger);
                    }

                    if(item.getFieldName().equals("lift")){
                        String inputString= item.getString();
                        Integer inputInteger= Integer.parseInt(inputString);
                        personalAccommodation.setLift(inputInteger);
                    }

                    if(item.getFieldName().equals("television")){
                        String inputString= item.getString();
                        Integer inputInteger= Integer.parseInt(inputString);
                        personalAccommodation.setTelevision(inputInteger);
                    }
                }
                else{
                    String randomName = RandomStringUtils.random(20, "abcdefghijklmnopqrstuvwxyz1234567890");
                    String fileName = item.getName();

                    int index = fileName.lastIndexOf("\\");
                    fileName = fileName.substring(index + 1);
                    fileName = randomName + fileName;
                    request.setAttribute("realFileName", fileName);

                    String basePath = "/Users/cannelloni/19s3/comp3900/project/capstone-project-supernb/Accommodation/out/artifacts/Accommodation_war_exploded/userimage";
                    String relativePath = "userimage/" + fileName;
                    File file = new File(basePath, fileName);

                    try {
                        item.write(file);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                    if(image0 == null){
                        image0 = relativePath;
                    }
                    else if(image1 == null){
                        image1 = relativePath;
                    }
                    else if(image2 == null){
                        image2 = relativePath;
                    }
                    else if(image3 == null){
                        image3 = relativePath;
                    }
                    else if(image4 == null){
                        image4 = relativePath;
                    }
                    else if(image5 == null){
                        image5 = relativePath;
                    }
                    else if(image6 == null){
                        image6 = relativePath;
                    }
                    else if(image7 == null){
                        image7 = relativePath;
                    }
                    else{
                        image8 = relativePath;
                    }
                }
            }

            if(personalAccommodation.getStartDate().after(personalAccommodation.getEndDate())){
                validDate = 0;
            }
            else{
                count  = dao.uploadPersonalAccommodation(personalAccommodation,image0,image1,image2,image3,image4,image5,image6,image7,image8);
            }
            json.put("state1", validDate);
            json.put("state2", count);
        }

        response.getWriter().write(json.toString());
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request, response);
    }
}
