package com.accommodation.web;

import com.accommodation.dao.AccommodationDao;
import com.accommodation.model.Accommodation;
import com.accommodation.model.CompanyAccommodation;
import com.accommodation.model.PersonalAccommodation;
import com.accommodation.utils.SearchUtils;
import com.mysql.cj.x.protobuf.MysqlxExpr;
import net.sf.json.JSONObject;
import org.apache.commons.beanutils.BeanUtils;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@WebServlet("/SearchSecondServlet")
public class SearchSecondServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        Map<String, String[]> map = request.getParameterMap();
// --------------------------------------------------------------------------------------------------------------------------
        JSONObject json = new JSONObject();
// ------------------------------------------------------------------------------------------------------------------------
        int pet = 0;
        if(request.getParameter("whetherPet").equals("yes")){
            pet = 1;
        }

        ArrayList<Accommodation> finalReturnList = new ArrayList<>();

// --------------------------------------------------------------------------------------------------------------------------
        if(request.getParameter("accommodationType").equals("Personal Accommodation")){
            List<PersonalAccommodation> personalFirstList = SearchUtils.searchPersonal(request, response);
//            System.out.println("------------------------------------------------------------------------------");
//            System.out.println("First"+personalFirstList.toString());
            ArrayList<PersonalAccommodation> personalPetList = new ArrayList<>();
            if(pet == 1){
                for(PersonalAccommodation acc: personalFirstList){
                    if(acc.getPet()==1){
                        personalPetList.add(acc);
                    }
                }
            }
            else{
                personalPetList.addAll(personalFirstList);
            }
// Amenities filter
//            System.out.println("------------------------------------------------------------------------------");
//            System.out.println("Second"+personalPetList.toString());
            ArrayList<PersonalAccommodation> personalAmenitiesList = new ArrayList<>();
            ArrayList<PersonalAccommodation> personalAmenitiesParkList = new ArrayList<>();
            ArrayList<PersonalAccommodation> personalAmenitiesGymList = new ArrayList<>();
            ArrayList<PersonalAccommodation> personalAmenitiesWifiList = new ArrayList<>();
            ArrayList<PersonalAccommodation> personalAmenitiesLiftList = new ArrayList<>();
            ArrayList<PersonalAccommodation> personalAmenitiesTelevisionList = new ArrayList<>();

            personalAmenitiesList.addAll(personalPetList);

            if(request.getParameter("park").equals("OK")){
                for(PersonalAccommodation acc : personalAmenitiesList){
                    if(acc.getPark()==1){
                        personalAmenitiesParkList.add(acc);
                    }
                }
            }
            else{
                personalAmenitiesParkList.addAll(personalAmenitiesList);
            }

            if(request.getParameter("gym").equals("OK")){
                for(PersonalAccommodation acc : personalAmenitiesParkList){
                    if(acc.getGym()==1){
                        personalAmenitiesGymList.add(acc);
                    }
                }
            }
            else {
                personalAmenitiesGymList.addAll(personalAmenitiesParkList);
            }

            if(request.getParameter("lift").equals("OK")){
                for(PersonalAccommodation acc : personalAmenitiesGymList){
                    if(acc.getLift()==1){
                        personalAmenitiesLiftList.add(acc);
                    }
                }
            }
            else {
                personalAmenitiesLiftList.addAll(personalAmenitiesGymList);
            }

            if(request.getParameter("television").equals("OK")){
                for(PersonalAccommodation acc : personalAmenitiesLiftList){
                    if(acc.getTelevision()==1){
                        personalAmenitiesTelevisionList.add(acc);
                    }
                }
            }
            else {
                personalAmenitiesTelevisionList.addAll(personalAmenitiesLiftList);
            }

            if(request.getParameter("wifi").equals("OK")){
                for(PersonalAccommodation acc : personalAmenitiesTelevisionList){
                    if(acc.getWifi()==1){
                        personalAmenitiesWifiList.add(acc);
                    }
                }
            }
            else {
                personalAmenitiesWifiList.addAll(personalAmenitiesTelevisionList);
            }
//            System.out.println("Third"+ personalAmenitiesWifiList.toString());
// ---------Rooms
            String bedroomString = request.getParameter("bedroom");
            String bathroomString = request.getParameter("bathroom");
            String kitchenString = request.getParameter("kitchen");

            Integer bedroom = Integer.parseInt(bedroomString);
            Integer bathroom = Integer.parseInt(bathroomString);
            Integer kitchen = Integer.parseInt(kitchenString);

            ArrayList<PersonalAccommodation> personalRoomList = new ArrayList<>();
            for (PersonalAccommodation acc : personalAmenitiesWifiList) {
                if((acc.getBathroom()== bathroom) && (acc.getBedroom() == bedroom) && (acc.getKitchen() == kitchen)) {
                    personalRoomList.add(acc);
                }
            }
//            System.out.println("------------------------------------------------------------------------------");
//            System.out.println("Forth" + personalRoomList.toString());
// ---------StructureType
            String house = "null";
            String unit = "null";
            String apartment = "null";
            ArrayList<PersonalAccommodation> personalStructureList = new ArrayList<>();

            if(request.getParameter("House").equals("OK")) {
                house = "House";
            }


            if(request.getParameter("Unit").equals("OK")) {
                unit = "Unit";
            }


            if(request.getParameter("Apartment").equals("OK")) {
                apartment = "Apartment";
            }

            for(PersonalAccommodation acc:personalRoomList) {
                if ((acc.getStructureType().equals(house)) || (acc.getStructureType().equals(unit)) || (acc.getStructureType().equals(apartment))) {
                    personalStructureList.add(acc);
                }
            }
//            System.out.println("------------------------------------------------------------------------------");
//            System.out.println("Fifth" + personalStructureList.toString());
// ---------RentType
            String entire = null;
            String privateRoom = null;
            String share = null;
            ArrayList<PersonalAccommodation> personalRentList = new ArrayList<>();

            if(request.getParameter("EntirePlace").equals("OK")) {
                entire = "Entire Place";
            }


            if(request.getParameter("PrivateRoom").equals("OK")) {
                privateRoom = "Private Room";
            }


            if(request.getParameter("ShareRoom").equals("OK")) {
                share = "Share Room";
            }

            for(PersonalAccommodation acc:personalStructureList) {
                if ((acc.getRentType().equals(entire)) || (acc.getRentType().equals(privateRoom)) || (acc.getRentType().equals(share))) {
                    personalRentList.add(acc);
                }
            }
// ---------FinalAdd
            finalReturnList.addAll(personalRentList);
//            System.out.println("------------------------------------------------------------------------------");
//            System.out.println("Sixthth" + finalReturnList.toString());
        }
        else{
// ---------Pet
            List<CompanyAccommodation> companyFirstList = SearchUtils.searchCompany(request, response);
            ArrayList<CompanyAccommodation> companyPetList = new ArrayList<>();
            if(pet == 1){
                for(CompanyAccommodation acc: companyFirstList){
                    if(acc.getPet()==1){
                        companyPetList.add(acc);
                    }
                }
            }
            else{
                companyPetList.addAll(companyFirstList);
            }
// ---------Star
//            System.out.println("-----------------------------------------------------------------------------------");
//            System.out.println("First"+companyPetList.toString());
            ArrayList<CompanyAccommodation> companyStarList = new ArrayList<>();
            Integer starOne = 0;
            Integer starTwo = 0;
            Integer starThree = 0;
            Integer starFour = 0;
            Integer starFive = 0;
            Integer starSix = 0;
            Integer starSeven = 0;

            if(request.getParameter("starOne").equals("OK")) {
                starOne= 1;
            }


            if(request.getParameter("starTwo").equals("OK")) {
                starTwo = 2;
            }


            if(request.getParameter("starThree").equals("OK")) {
                starThree = 3;
            }

            if(request.getParameter("starFour").equals("OK")) {
                starFour = 4;
            }


            if(request.getParameter("starFive").equals("OK")) {
                starFive = 5;
            }


            if(request.getParameter("starSix").equals("OK")) {
                starSix = 6;
            }

            if(request.getParameter("starSeven").equals("OK")) {
                starSeven = 7;
            }

            for(CompanyAccommodation acc : companyPetList){
                if ((acc.getStar() == starOne)||(acc.getStar() == starTwo)||(acc.getStar() == starThree)||(acc.getStar() == starFour)||(acc.getStar() == starFive)||(acc.getStar() == starSix)||(acc.getStar() == starSeven)){
                    companyStarList.add(acc);
                }
            }
//            System.out.println("-----------------------------------------------------------------------------------");
//            System.out.println("Second"+ companyStarList.toString());
// ---------HotelType
            ArrayList<CompanyAccommodation> companyTypeList = new ArrayList<>();
            String capsuleHotel = null;
            String boutiqueHotel = null;
            String loveHotel = null;
            String ryokan = null;

            if(request.getParameter("CapsuleHotel").equals("OK")) {
                capsuleHotel = "Capsule Hotel";
            }


            if(request.getParameter("BoutiqueHotel").equals("OK")) {
                boutiqueHotel = "Boutique Hotel";
            }


            if(request.getParameter("LoveHotel").equals("OK")) {
                loveHotel = "Love Hotel";
            }

            if(request.getParameter("Ryokan").equals("OK")) {
                ryokan = "Ryokan";
            }

            for(CompanyAccommodation acc:companyStarList) {
                if ((acc.getHotelType().equals(capsuleHotel)) || (acc.getHotelType().equals(boutiqueHotel)) || (acc.getHotelType().equals(loveHotel)) || (acc.getHotelType().equals(ryokan))) {
                    companyTypeList.add(acc);
                }
            }
//            System.out.println("-----------------------------------------------------------------------------------");
//            System.out.println("Third"+ companyTypeList.toString());
// ---------Final List
            finalReturnList.addAll(companyTypeList);
        }
// --------------------------------------------------------------------------------------------------------------------------
// --------------------------------------------------------------------------------------------------------------------------
        // --------------------------------------------------------------------------------------------------------------------------
        // --------------------------------------------------------------------------------------------------------------------------
        // --------------------------------------------------------------------------------------------------------------------------
        // --------------------------------------------------------------------------------------------------------------------------
        // --------------------------------------------------------------------------------------------------------------------------
        json.put("state", 1);
        json.put("returnList", finalReturnList);
        response.getWriter().write(json.toString());
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request, response);
    }
}
