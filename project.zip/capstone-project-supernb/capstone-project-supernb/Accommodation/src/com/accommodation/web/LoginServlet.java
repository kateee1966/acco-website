package com.accommodation.web;

import com.accommodation.dao.UserDao;
import com.accommodation.model.CommonVars;
import com.accommodation.model.User;
import com.accommodation.utils.EncUtils;
import net.sf.json.JSONObject;
import org.apache.commons.beanutils.BeanUtils;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.Map;

/**
 * @param
 */

/**
 * Input : userName, password
 * Output : user, state 1 means success
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
//        String username = req.getParameter("userID");
//        String password = req.getParameter("password");
//
//        User loginUser = new User();
//        loginUser.setUserName(username);
//        loginUser.setPassword(password);

        Map<String, String[]> map = request.getParameterMap();
        User loginUser = new User();
        try {
            BeanUtils.populate(loginUser, map);
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        }


        UserDao dao = new UserDao();
        try {
            String original = loginUser.getPassword();
            loginUser.setPassword(EncUtils.encryptString(original));
        } catch (Exception e) {
            e.printStackTrace();
        }
        User user = dao.login(loginUser);

        JSONObject json = new JSONObject();
        if(user == null){
            // 0 is false
            json.put("state", 0);
            json.put("user", user);
        }
        else{
            // 1 is true
            json.put("state", 1);
            json.put("user", user);
            HttpSession httpSession = request.getSession();
            if (httpSession.getAttribute(CommonVars.SESSION_LOGIN_KEY) == null) {
                httpSession.setAttribute(CommonVars.SESSION_LOGIN_KEY, user.getUserName());
            }
        }

        response.getWriter().write(json.toString());
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request, response);
    }
}
