package com.accommodation.web;

import com.accommodation.dao.AccommodationDao;
import com.accommodation.model.Accommodation;
import net.sf.json.JSONObject;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet("/PostItemServlet")
public class PostItemServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        String userName = request.getParameter("userName");

        AccommodationDao dao = new AccommodationDao();
        List<Accommodation> returnList= dao.postItem(userName);
        JSONObject json = new JSONObject();

        json.put("state", 1);
        json.put("returnList", returnList);

        response.getWriter().write(json.toString());
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request, response);
    }
}
