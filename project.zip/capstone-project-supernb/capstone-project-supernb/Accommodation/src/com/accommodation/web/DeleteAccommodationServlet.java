package com.accommodation.web;

import com.accommodation.dao.AccommodationDao;
import com.accommodation.model.Accommodation;
import net.sf.json.JSONObject;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/DeleteAccommodationServlet")
public class DeleteAccommodationServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        String accommodationIDString = request.getParameter("accommodationID");
        Integer accommodationID = Integer.parseInt(accommodationIDString);
        AccommodationDao dao = new AccommodationDao();
        Accommodation inputAccommodation = new Accommodation();
        inputAccommodation.setAccommodationID(accommodationID);
        Accommodation outputAccommodation = dao.concreteAccommodation(inputAccommodation);
        JSONObject json = new JSONObject();
        if(outputAccommodation.getWhetherComplete()==2){
            json.put("state" , 0);
        }
        else{
            dao.deleteAccommodation(accommodationID);
            json.put("state" , 1);
        }

        response.getWriter().write(json.toString());
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request, response);
    }
}
