package com.accommodation.utils;

import com.accommodation.dao.AccommodationDao;
import com.accommodation.model.Accommodation;
import com.accommodation.model.CompanyAccommodation;
import com.accommodation.model.PersonalAccommodation;
import org.apache.commons.beanutils.BeanUtils;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class SearchUtils {

    public static List<CompanyAccommodation> searchCompany(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
        request.setCharacterEncoding("utf-8");
        Map<String, String[]> map = request.getParameterMap();
// --------------------------------------------------------------------------------------------------------------------------
        String location = request.getParameter("location");
        ArrayList<String> allLocationString = new ArrayList<String>();
        for (String str : location.split("%20")) {
            allLocationString.add(str);
        }

        String datefilter = request.getParameter("datefilter");
        ArrayList<String> allDateString = new ArrayList<String>();
        for (String str : datefilter.split(" - ")) {
            allDateString.add(str);
        }

        String startDateString = allDateString.get(0);
        String endDateString = allDateString.get(1);

        String lowOrHigh = null;
        if(request.getParameter("sort").equals("Low Price")){
            lowOrHigh = "asc";
        }
        else{
            lowOrHigh = "desc";
        }
// --------------------------------------------------------------------------------------------------------------------------
        AccommodationDao dao = new AccommodationDao();
// --------------------------------------------------------------------------------------------------------------------------
        CompanyAccommodation inputAccommodation = new CompanyAccommodation();
        inputAccommodation.setGuestNum(Integer.parseInt(request.getParameter("guestNum")));
        try {
            inputAccommodation.setStartDateString(startDateString);
            inputAccommodation.setEndDateString(endDateString);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        List<CompanyAccommodation> firstList = new ArrayList<CompanyAccommodation>();
        List<CompanyAccommodation> secondList = new ArrayList<CompanyAccommodation>();
        List<CompanyAccommodation> finalList = new ArrayList<CompanyAccommodation>();
// ------------------------------------------------------------------------------------------------------------------------
        for(String str: allLocationString){
            inputAccommodation.setCity(str);
            firstList.addAll(dao.searchSecondCompany(inputAccommodation, lowOrHigh));
        }
        for(CompanyAccommodation acc : firstList){
            if(acc.getGuestNum() >= inputAccommodation.getGuestNum() && acc.getEndDate().after(inputAccommodation.getEndDate()) && acc.getStartDate().before(inputAccommodation.getStartDate())){
                secondList.add(acc);
            }
        }
        if(secondList.size()==1){
            finalList.add(secondList.get(0));
        }
        for(int i = 0; i<secondList.size() -1 ; i++){
            int flag = 0;
            for(int j=i+1; j<secondList.size(); j++){
                if(secondList.get(i).getAccommodationID().equals(secondList.get(j).getAccommodationID()) && i!=j ){
                    flag = 1;
                }
            }
            if(flag == 0){
                finalList.add(secondList.get(i));
            }
        }
        if(secondList.size()>1){
            finalList.add(secondList.get(secondList.size()-1));
        }
        return finalList;
    }






    public static List<PersonalAccommodation> searchPersonal(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
        request.setCharacterEncoding("utf-8");
        Map<String, String[]> map = request.getParameterMap();
// --------------------------------------------------------------------------------------------------------------------------
        String location = request.getParameter("location");
        ArrayList<String> allLocationString = new ArrayList<String>();
        for (String str : location.split("%20")) {
            allLocationString.add(str);
        }

        String datefilter = request.getParameter("datefilter");
        ArrayList<String> allDateString = new ArrayList<String>();
        for (String str : datefilter.split(" - ")) {
            allDateString.add(str);
        }

        String startDateString = allDateString.get(0);
        String endDateString = allDateString.get(1);

        String lowOrHigh = null;
        if(request.getParameter("sort").equals("Low Price")){
            lowOrHigh = "asc";
        }
        else{
            lowOrHigh = "desc";
        }
// --------------------------------------------------------------------------------------------------------------------------
        AccommodationDao dao = new AccommodationDao();
// --------------------------------------------------------------------------------------------------------------------------
        PersonalAccommodation inputAccommodation = new PersonalAccommodation();
        inputAccommodation.setGuestNum(Integer.parseInt(request.getParameter("guestNum")));
        try {
            inputAccommodation.setStartDateString(startDateString);
            inputAccommodation.setEndDateString(endDateString);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        List<PersonalAccommodation> firstList = new ArrayList<PersonalAccommodation>();
        List<PersonalAccommodation> secondList = new ArrayList<PersonalAccommodation>();
        List<PersonalAccommodation> finalList = new ArrayList<PersonalAccommodation>();
// ------------------------------------------------------------------------------------------------------------------------
        for(String str: allLocationString){
            inputAccommodation.setCity(str);
            firstList.addAll(dao.searchSecondPersonal(inputAccommodation, lowOrHigh));
        }
        for(PersonalAccommodation acc : firstList){
            if(acc.getGuestNum() >= inputAccommodation.getGuestNum() && acc.getEndDate().after(inputAccommodation.getEndDate()) && acc.getStartDate().before(inputAccommodation.getStartDate())){
                secondList.add(acc);
            }
        }
        if(secondList.size()==1){
            finalList.add(secondList.get(0));
        }
        for(int i = 0; i<secondList.size() -1 ; i++){
            int flag = 0;
            for(int j=i+1; j<secondList.size(); j++){
                if(secondList.get(i).getAccommodationID().equals(secondList.get(j).getAccommodationID()) && i!=j ){
                    flag = 1;
                }
            }
            if(flag == 0){
                finalList.add(secondList.get(i));
            }
        }
        if(secondList.size()>1){
            finalList.add(secondList.get(secondList.size()-1));
        }
        return finalList;
    }
}
