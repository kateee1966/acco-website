# Project Topic: Accommodation Web Portal 7
# Group: SuperNB
Group Member:
            Wenfei Guo(z5135080)
            Tao Bai (z5111218)
            Zhichao He (z5282955)
            Shengchen Xue (z5111075)
            
Project Decription: 
Our team’s goal is to build a convenient website to help customers to reserve or rent a suitable place and allow providers to publish their accommodations. In our project, we will concentrate on implement of functional design rather than user interface design. For that reason, UI design will have lower priority. Also, implementing concrete search filter has higher priority because it is an advanced feature which other websites do not have.

Project Epics:

Accommodation Advertising Module    
Accommodation Booking Module    
Visitor Request Module    
Accommodation Search Module    
Accomodation Review Module    
Google Map    
Auto-Recommendation    
User Information Management System (*Some features may partially implemented)    

